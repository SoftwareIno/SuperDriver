#!/bin/bash
echo "Inserisci il code name della tua distro per continuare"
read code
if [[ $code =~ "Focal Fossa" ]] ; then
  $(sudo rm /etc/default/grub)
  $(sudo cp ~/.touchdriver/grub /etc/default/grub)
  cp ~/.touchdriver/grub ~/Scrivania/grub
  $(sudo update-grub)
  echo "Instrallare anche i componenti aggiuntivi? [S/n]"
  read add
  if [[ $add == "n" ]] ; then
    echo "Attendere, chiusura in corso"
    echo "Il tuo computer verrà riavviato tra un minuto per applicare le modifiche, salvare tutti i documenti e file aperti."
    notify-send "Il tuo computer verrà riavviato tra 1 minuto" -u critical
    echo "riavviare ora? [S/n]"
    read reboottime
    if [[ $reboottime == "S" ]] ; then
      $(systemctl reboot)
      notify-send "riavvio!"
    fi
    $(sh ~/.touchdriver/60reboot.sh)
  fi
  if [[ $add == "S" ]] ; then
    #echo "IMPORTANTE! Per poter utilizzare correttamente i componenti aggiuntivi:"
    #echo "Aprire un altro terminale ed eseguire: sudo apt install xdotool acpi"
    echo "Attendere. Elaborazione in corso"
    echo "------------------------------------------------------------------"
    echo "Verranno installati i seguenti pacchetti:"
    echo "batteryChekerNotification rightClik-wacomPen"
    cp ~/.touchdriver/bat.sh ~/.battery.sh
    cp ~/.touchdriver/pen.sh ~/.rightpen.sh
    cp ~/.touchdriver/bat+.png ~/.bat+.png
    cp ~/.touchdriver/bat-.png ~/.bat-.png
    cp ~/.touchdriver/bat.desktop ~/.config/autostart/bat.desktop
    cp ~/.touchdriver/pen.desktop ~/.config/autostart/pen.desktop
    cp ~/.touchdriver/.grub ~/.grub
    echo "[===================================================>] 100%"
    echo "Tutti i componenti aggiuntivi sono stati installati con successo!"
    echo "------------------------------------------------------------------"
    echo "N.B.: rightClick-wacomPen funxionerà solo su Xorg (X11)! Non tentare di utilizzare su Wayland!"
    echo "Il tuo computer verrà riavviato tra un minuto per applicare le modifiche, salvare tutti i documenti e file aperti."
    notify-send "Il tuo computer verrà riavviato tra 1 minuto" -u critical
    echo "riavviare ora? [S/n]"
    read reboottime
    if [[ $reboottime == "S" ]] ; then
      $(systemctl reboot)
      notify-send "riavvio!"
    fi
    $(sh ~/.touchdriver/60reboot.sh)
  fi
else
  echo "Errore di esecuzione! La versione del tuo sistema operativo non corrispinde con quella dei driver!"
fi

