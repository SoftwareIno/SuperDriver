#!/bin/bash
run=1
while [[ $run = 1 ]] ; do
  wacomClick=$(xinput list-props 18)
  sessiontype=$(echo $XDG_SESSION_TYPE)
  win=0
  run1=0
  if [[ $sessiontype = "wayland" ]] ; then
    echo "Sessione Wayland rilevata! Impossibile utilizzare questo driver su Wayland. Riavvio del computer." > ~/Scrivania/rightClick-wacomPen_Error-$(date -I).log
    notify-send "Sessione Wayland rilevata! Impossibile utilizzare questo driver su Wayland. Riavvio del computer." -u critical
    $(sudo rm /etc/default/grub)
    $(sudo cp ~/.grub /etc/default/grub)
    $(sudo update-grub)
    sleep 10
    $(systemctl reboot)
  fi
  if [[ $win = 0 ]] ; then
    if [[ $wacomClick =~ "Wacom Serial IDs (328):	18805, -2145028742, 17, -2145028742, 17" ]] ; then
      run1=1
      while [[ $run1 = 1 ]] ; do
        $(xdotool click 3)
        wacomClick=$(xinput list-props 18)
        if [[ $wacomClick =~ "Wacom Serial IDs (328):	18805, -2145028742, 17, 0, 0" ]] ; then
          run1=0
        fi
        sleep 0.01
      done
      win=0
    fi
  fi
  sleep 0.1
done
