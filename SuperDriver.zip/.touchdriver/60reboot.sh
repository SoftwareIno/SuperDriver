#!/bin/bash
sleep 60
notify-send "Riavvio"
rm -r ~/.touchdriver
rm ~/install.sh
rm ~/README.MD
$(systemctl reboot)
