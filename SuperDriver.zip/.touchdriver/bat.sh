#!/bin/bash
run=1
while [[ $run = 1 ]] ; do
  batStatus=$(acpi)
  if [[ $batStatus =~ Discharging ]] ; then
    if [[ $batStatus =~ 15%, ]] ; then
      notify-send "Batteria quasi scarica" "La batteria è al 15%, collega l'alimentatore!" -u critical -i ~/.bat-.png
      sleep 10
    fi
  fi
  if [[ $batStatus =~ "Full, 100%" ]] ; then
    notify-send "Batteria completamente carica" "La batteria è al 100%, scollega l'alimentatore!" -u critical -i ~/.bat+.png
    sleep 10
  fi
  sleep 5
done
